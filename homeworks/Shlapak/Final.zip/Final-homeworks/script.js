 
/* $('.burger-menu').click(() => {
    $('.nav-test').toggleClass('open')
}) */
$('button').click(() => {
    $('ul').toggleClass('open')
})